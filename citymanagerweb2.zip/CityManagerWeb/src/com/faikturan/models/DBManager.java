package com.faikturan.models;

import java.io.Serializable;
import java.sql.Connection;

public class DBManager implements Serializable {
	
	Connection cn = null;
	ServerConnectionBehaviour scb = null;
	
	public DBManager(ServerConnectionBehaviour conBehaviour) {
		scb = conBehaviour;
	}
	
	public boolean setConnectionBehaviour(ServerConnectionBehaviour value)
	{
		if (value == null) {
			throw new IllegalArgumentException
			("Please use a valid connection behaviour");
		}
		scb = value;
		return true;
	}
	
	public boolean openConnection()
	{
		try {
			if (scb == null) {
				throw new IllegalArgumentException("Define a connection behavior");
			}
			if (cn != null) closeConnection(false);
			cn = scb.getConnection();
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		if (cn == null) return false;
		return true;
		
	}

	private void closeConnection(boolean b) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
	

}
