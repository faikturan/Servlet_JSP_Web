package com.faikturan.sessionlisteners;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

@WebListener
public class SessionTrackingAndLogging implements HttpSessionAttributeListener {
    public SessionTrackingAndLogging() {
        
    }
    
    public void attributeAdded(HttpSessionBindingEvent hsbe)  { 
         System.out.printf("Attribute Added to session: %s\t%s\n"
        		 , hsbe.getName()
        		 ,hsbe.getValue());
    }
    
    public void attributeRemoved(HttpSessionBindingEvent hsbe)  { 
    	 System.out.printf("Attribute Removed from session: %s\t%s\n"
        		 , hsbe.getName()
        		 ,hsbe.getValue());
    }

    public void attributeReplaced(HttpSessionBindingEvent hsbe)  { 
    	 System.out.printf("Attribute Replaced in session: %s\t%s\n"
        		 , hsbe.getName()
        		 ,hsbe.getValue());
    }
	
}
