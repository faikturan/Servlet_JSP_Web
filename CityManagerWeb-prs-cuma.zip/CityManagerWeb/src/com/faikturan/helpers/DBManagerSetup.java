package com.faikturan.helpers;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.faikturan.models.DBManager;
import com.faikturan.models.MySQLServerConnectionBehavior;
import com.faikturan.models.ServerConnectionBehavior;

public class DBManagerSetup implements ServletContextListener {
private DBManager dbm = null;
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		if (dbm != null) {
			if (dbm.isConnected()) {
				dbm.closeConnection(false);
			}
		}
		dbm = null;

	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		ServletContext sc = sce.getServletContext();
		String uid = sc.getInitParameter("dbuserid");
		String pwd = sc.getInitParameter("dbuserpwd");
		String cat = sc.getInitParameter("dbinitcat");
		
		ServerConnectionBehavior scb = 
				new MySQLServerConnectionBehavior(uid, pwd, cat);
		dbm = new DBManager(scb);
		sc.setAttribute("WorldDBManager", dbm);
		System.out.println("WorldDBManager created and added to context");

	}

}
