package com.faikturan.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.faikturan.models.DBManager;
import com.faikturan.models.MySQLServerConnectionBehavior;
import com.faikturan.models.ServerConnectionBehavior;

@WebServlet("/listallcities.do")
public class ListAllCities extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ListAllCities() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StringBuilder sb = new StringBuilder("<html><body>");
		
		String uid = getServletContext().getInitParameter("dbuserid");
		String pwd = getServletContext().getInitParameter("dbuserpwd");
		String cat = getServletContext().getInitParameter("dbinitcat");
		
		ServerConnectionBehavior scb = new MySQLServerConnectionBehavior(uid, pwd, cat);
		System.out.println(scb.getConnectionDetails());
		System.out.println(scb.getConnectionURL());
		
		DBManager dbm = new DBManager(scb);
		
		try {
			if (!dbm.isConnected()) {
				if (!dbm.openConnection()) {
					sb.append("Could not connect to the database...");
				}
			}
			sb.append("<table border=1>"
					+"<tr><td>ID</td><td>NAME</td><td>COUNTRY_CODE</td>"
					+"<td>DISTRICT</td><td>POPULATION</td></tr>");
			String query ="SELECT * FROM city WHERE COUNTRYCODE = 'TUR'"
					+"order by District ASC, Population DESC";
			ResultSet rs = dbm.ExecuteResultSet(query);
			while (rs.next()) {
				int id = rs.getInt("ID");
				String name = rs.getString("NAME");
				String ctry = rs.getString("CountryCode");
				String dist = rs.getString("District");
				int pop = rs.getInt("Population");
				
				sb.append("<tr><td>" + id + "</td>"
						+"<td>" +name + "</td>"
						+"<td>" + ctry + "</td>"
						+"<td>" + dist + "</td>"
						+"<td>" + pop + "</td></tr>");
			}
			sb.append("</table>");
		} catch (Exception e) {
			sb.append("<h1>ERROR: " +e.getMessage() + "</h1>");
		}
		sb.append("</body></html>");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println(sb);
	}

}
