package com.faikturan.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.faikturan.models.DBManager;
import com.faikturan.models.MySQLServerConnectionBehavior;
import com.faikturan.models.ServerConnectionBehavior;

@WebServlet("/listallcities.do")
public class ListAllCities extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ListAllCities() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StringBuilder sb = new StringBuilder("<html><body>");
		
		String uid = getServletContext().getInitParameter("dbuserid");
		String pwd = getServletContext().getInitParameter("dbuserpwd");
		String cat = getServletContext().getInitParameter("dbinitcat");
		
		ServerConnectionBehavior scb = new MySQLServerConnectionBehavior(uid, pwd, cat);
		System.out.println(scb.getConnectionDetails());
		System.out.println(scb.getConnectionURL());
		
		DBManager dbm = new DBManager(scb);
		
		try {
			if (!dbm.isConnected()) {
				if (!dbm.openConnection()) {
					sb.append("Could not connect to the database...");
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
